<footer class="mt-5 py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="site-name mb-2"><?= esc($settings['site_name'] ?? '') ?></div>
                <p class="small mb-0" style="color:#8b7baa; line-height:1.75"><?= esc($settings['site_desc'] ?? '') ?></p>
            </div>
            <div class="col-md-4">
                <div class="section-label mb-3">연락처</div>
                <?php if (!empty($settings['phone'])): ?>
                    <div class="contact-item mb-1"><i class="bi bi-telephone me-2"></i><?= esc($settings['phone']) ?></div>
                <?php endif; ?>
                <?php if (!empty($settings['email'])): ?>
                    <div class="contact-item mb-1"><i class="bi bi-envelope me-2"></i><?= esc($settings['email']) ?></div>
                <?php endif; ?>
                <?php if (!empty($settings['address'])): ?>
                    <div class="contact-item"><i class="bi bi-geo-alt me-2"></i><?= esc($settings['address']) ?></div>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <div class="section-label mb-3">SNS</div>
                <div class="d-flex gap-3">
                    <?php if (!empty($settings['instagram'])): ?>
                        <a href="<?= esc($settings['instagram']) ?>" target="_blank" class="social-icon"><i class="bi bi-instagram"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($settings['youtube'])): ?>
                        <a href="<?= esc($settings['youtube']) ?>" target="_blank" class="social-icon"><i class="bi bi-youtube"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($settings['blog'])): ?>
                        <a href="<?= esc($settings['blog']) ?>" target="_blank" class="social-icon"><i class="bi bi-rss"></i></a>
                    <?php endif; ?>
                    <?php if (!empty($settings['kakao'])): ?>
                        <a href="<?= esc($settings['kakao']) ?>" target="_blank" class="social-icon"><i class="bi bi-chat-fill"></i></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <hr class="my-4">

        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 copyright">
            <span><?= esc($settings['copyright'] ?? '') ?></span>
            <?php if (!empty($settings['business_num'])): ?>
                <span>사업자번호: <?= esc($settings['business_num']) ?></span>
            <?php endif; ?>
        </div>
    </div>
</footer>
