<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $seo = new \App\Libraries\SeoHelper($settings);
    echo $seo->render($page ?? null);
    echo $seo->gaScript();
    ?>
    <?php if (!empty($settings['favicon'])): ?>
    <link rel="icon" href="/<?= esc($settings['favicon']) ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="/themes/spring/css/style.css">
</head>
<body>

<?= $this->include('components/navbar') ?>

<main>
    <?php foreach (['success' => 'success', 'warning' => 'warning', 'error' => 'danger'] as $key => $cls): ?>
        <?php if (session()->has($key)): ?>
        <div class="sp-wrap py-2">
            <div class="alert alert-<?= $cls ?> alert-dismissible fade show mt-2">
                <?= esc(session($key)) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        </div>
        <?php endif; ?>
    <?php endforeach; ?>

    <?php $isHome = (uri_string() === '' || uri_string() === '/'); ?>
    <?php if (!$isHome && !empty($subLeftBanners)): ?>
    <div class="sp-wrap sp-layout">
        <aside class="sp-sidebar">
            <?php foreach ($subLeftBanners as $b): ?>
            <div class="sp-banner-slot mb-3">
                <?php if ($b['link_url']): ?>
                <a href="<?= esc($b['link_url']) ?>" target="<?= esc($b['link_target']) ?>">
                    <img src="/<?= esc($b['image_path']) ?>" alt="" class="sp-banner-img">
                </a>
                <?php else: ?>
                <img src="/<?= esc($b['image_path']) ?>" alt="" class="sp-banner-img">
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </aside>
        <div class="sp-content">
            <?= $this->renderSection('content') ?>
        </div>
    </div>
    <?php else: ?>
    <?= $this->renderSection('content') ?>
    <?php endif; ?>
</main>

<?= $this->include('components/footer') ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="/themes/spring/js/main.js"></script>
<?= $this->renderSection('scripts') ?>
</body>
</html>
