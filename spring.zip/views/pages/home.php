<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<!-- 메인 상단 배너 -->
<?php if (!empty($mainTopBanners)): ?>
<div class="sp-main-banner-section sp-main-banner-section--top">
    <div class="sp-wrap">
        <?php foreach ($mainTopBanners as $b): ?>
        <?php if ($b['link_url']): ?>
        <a href="<?= esc($b['link_url']) ?>" target="<?= esc($b['link_target']) ?>">
            <img src="/<?= esc($b['image_path']) ?>" alt="" class="sp-main-banner-img">
        </a>
        <?php else: ?>
        <img src="/<?= esc($b['image_path']) ?>" alt="" class="sp-main-banner-img">
        <?php endif; ?>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- 히어로 -->
<section class="hero-section">
    <div class="container py-5 text-center position-relative">
        <p class="sp-hero-tag">✦ Welcome</p>
        <h1 class="display-5 fw-bold mb-3"><?= esc($settings['site_name'] ?? '') ?></h1>
        <p class="lead mb-4 sp-hero-desc"><?= esc($settings['site_desc'] ?? '') ?></p>
        <div class="d-flex gap-3 justify-content-center flex-wrap">
            <a href="/contact" class="btn btn-primary btn-lg px-4">문의하기</a>
            <a href="/service" class="btn btn-outline-primary btn-lg px-4">서비스 보기</a>
        </div>
    </div>
</section>

<!-- 서비스 소개 -->
<section class="py-5">
    <div class="sp-wrap">
        <h2 class="text-center fw-bold mb-1" style="color:var(--primary-dk)">우리의 서비스</h2>
        <p class="text-center mb-4" style="color:var(--text-muted);font-size:.9rem">고객의 성공을 위한 최선을 다합니다</p>
        <div class="row g-4">
            <?php
            $services = [
                ['icon' => 'bi-laptop',  'title' => '웹사이트 제작', 'desc' => '기업 홈페이지부터 쇼핑몰까지 빠르고 정확하게 제작합니다.'],
                ['icon' => 'bi-phone',   'title' => '반응형 디자인', 'desc' => '모든 기기에서 최적화된 화면을 제공합니다.'],
                ['icon' => 'bi-headset', 'title' => '유지보수',      'desc' => '제작 후에도 지속적인 관리와 지원을 제공합니다.'],
            ];
            foreach ($services as $s):
            ?>
            <div class="col-md-4">
                <div class="card h-100 text-center p-4 border-0 shadow-sm">
                    <i class="bi <?= $s['icon'] ?> fs-1 mb-3" style="color:var(--primary)"></i>
                    <h5 class="fw-bold mb-2"><?= $s['title'] ?></h5>
                    <p class="small mb-0" style="color:var(--text-muted)"><?= $s['desc'] ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- 최신 공지 -->
<?php if (!empty($latestPosts)): ?>
<section class="py-5" style="background:var(--primary-lt)">
    <div class="sp-wrap">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="fw-bold mb-0" style="color:var(--primary-dk)">최신 공지사항</h5>
            <a href="/board/notice" class="small text-decoration-none" style="color:var(--primary)">
                전체보기 <i class="bi bi-chevron-right"></i>
            </a>
        </div>
        <div class="list-group">
            <?php foreach ($latestPosts as $post): ?>
            <a href="/board/notice/<?= $post['id'] ?>"
               class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"
               style="border-color:var(--border)">
                <span><?= esc($post['title']) ?></span>
                <span class="small" style="color:var(--text-muted)"><?= substr($post['created_at'], 0, 10) ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- CTA -->
<section class="py-5 text-center" style="background:#3d2c35;color:#fff">
    <div class="sp-wrap">
        <h3 class="fw-bold mb-2">프로젝트를 시작할 준비가 되셨나요?</h3>
        <p class="mb-4" style="color:#c4a8b3">지금 바로 문의하세요. 빠르게 답변드립니다.</p>
        <div class="d-flex gap-3 justify-content-center flex-wrap">
            <?php if (!empty($settings['phone'])): ?>
            <a href="tel:<?= esc($settings['phone']) ?>" class="btn btn-outline-light px-4">
                <i class="bi bi-telephone me-1"></i><?= esc($settings['phone']) ?>
            </a>
            <?php endif; ?>
            <a href="/contact" class="btn btn-primary px-4">온라인 문의</a>
        </div>
    </div>
</section>

<!-- 메인 하단 배너 -->
<?php if (!empty($mainBotBanners)): ?>
<div class="sp-main-banner-section sp-main-banner-section--bottom">
    <div class="sp-wrap">
        <?php foreach ($mainBotBanners as $b): ?>
        <?php if ($b['link_url']): ?>
        <a href="<?= esc($b['link_url']) ?>" target="<?= esc($b['link_target']) ?>">
            <img src="/<?= esc($b['image_path']) ?>" alt="" class="sp-main-banner-img">
        </a>
        <?php else: ?>
        <img src="/<?= esc($b['image_path']) ?>" alt="" class="sp-main-banner-img">
        <?php endif; ?>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<?= $this->endSection() ?>
